﻿// MISRA C:2012 Rule 14.4 — 控制表达式本质上必须是布尔类型
// 检测 if/while/for/do-while 的控制表达式类型是否为布尔类型

#include "clang/AST/ASTContext.h"
#include "clang/AST/Expr.h"
#include "clang/AST/Stmt.h"
#include "clang/AST/RecursiveASTVisitor.h"
#include "clang/StaticAnalyzer/Core/BugReporter/BugType.h"
#include "clang/StaticAnalyzer/Core/Checker.h"
#include "clang/StaticAnalyzer/Core/PathSensitive/AnalysisManager.h"
#include "clang/StaticAnalyzer/Core/PathSensitive/CheckerContext.h"
#include "clang/StaticAnalyzer/Checkers/BuiltinCheckerRegistration.h"

using namespace clang;
using namespace ento;

namespace {

class MISRAC_14_4_Checker : public Checker<check::EndOfTranslationUnit> {
  mutable std::unique_ptr<BugType> BT;

public:
  MISRAC_14_4_Checker()
      : BT(new BugType(this, "MISRA C:2012 Rule 14.4",
                        "控制表达式本质上必须是布尔类型")) {}

  // 判断表达式是否本质上是布尔类型
  bool isEssentiallyBoolean(const Expr *E, ASTContext &Ctx) const {
    if (!E)
      return true;

    QualType T = E->getType();
    if (T->isBooleanType())
      return true;

    // 检查是否为比较/逻辑运算符
    if (const auto *BO = dyn_cast<BinaryOperator>(E->IgnoreParenImpCasts())) {
      switch (BO->getOpcode()) {
      case BO_LT: case BO_GT: case BO_LE: case BO_GE:
      case BO_EQ: case BO_NE:
      case BO_LAnd: case BO_LOr:
        return true;
      default:
        break;
      }
    }

    // 检查逻辑非
    if (const auto *UO = dyn_cast<UnaryOperator>(E->IgnoreParenImpCasts())) {
      if (UO->getOpcode() == UO_LNot)
        return true;
    }

    return false;
  }

  void checkEndOfTranslationUnit(const TranslationUnitDecl *TU,
                                 AnalysisManager &Mgr,
                                 BugReporter &BR) const {
    if (!TU)
      return;

    ASTContext &Ctx = Mgr.getASTContext();

    class Visitor : public RecursiveASTVisitor<Visitor> {
      const MISRAC_14_4_Checker *Checker;
      BugReporter &BR;
      ASTContext &Ctx;

    public:
      Visitor(const MISRAC_14_4_Checker *C, BugReporter &B, ASTContext &Ctx)
          : Checker(C), BR(B), Ctx(Ctx) {}

      bool VisitIfStmt(IfStmt *IS) {
        const Expr *Cond = IS->getCond();
        if (!Checker->isEssentiallyBoolean(Cond, Ctx)) {
          PathDiagnosticLocation PDLoc(Cond->getBeginLoc(), BR.getSourceManager());
          auto Report = std::make_unique<BasicBugReport>(
              *Checker->BT,
              "MISRA C:2012 Rule 14.4: if 语句的控制表达式本质上必须是布尔类型",
              PDLoc);
          Report->addRange(Cond->getSourceRange());
          BR.emitReport(std::move(Report));
        }
        return true;
      }

      bool VisitWhileStmt(WhileStmt *WS) {
        const Expr *Cond = WS->getCond();
        if (!Checker->isEssentiallyBoolean(Cond, Ctx)) {
          PathDiagnosticLocation PDLoc(Cond->getBeginLoc(), BR.getSourceManager());
          auto Report = std::make_unique<BasicBugReport>(
              *Checker->BT,
              "MISRA C:2012 Rule 14.4: while 语句的控制表达式本质上必须是布尔类型",
              PDLoc);
          Report->addRange(Cond->getSourceRange());
          BR.emitReport(std::move(Report));
        }
        return true;
      }

      bool VisitForStmt(ForStmt *FS) {
        const Expr *Cond = FS->getCond();
        if (Cond && !Checker->isEssentiallyBoolean(Cond, Ctx)) {
          PathDiagnosticLocation PDLoc(Cond->getBeginLoc(), BR.getSourceManager());
          auto Report = std::make_unique<BasicBugReport>(
              *Checker->BT,
              "MISRA C:2012 Rule 14.4: for 语句的控制表达式本质上必须是布尔类型",
              PDLoc);
          Report->addRange(Cond->getSourceRange());
          BR.emitReport(std::move(Report));
        }
        return true;
      }

      bool VisitDoStmt(DoStmt *DS) {
        const Expr *Cond = DS->getCond();
        if (!Checker->isEssentiallyBoolean(Cond, Ctx)) {
          PathDiagnosticLocation PDLoc(Cond->getBeginLoc(), BR.getSourceManager());
          auto Report = std::make_unique<BasicBugReport>(
              *Checker->BT,
              "MISRA C:2012 Rule 14.4: do-while 语句的控制表达式本质上必须是布尔类型",
              PDLoc);
          Report->addRange(Cond->getSourceRange());
          BR.emitReport(std::move(Report));
        }
        return true;
      }
    };

    Visitor V(this, BR, Ctx);
    V.TraverseDecl(const_cast<TranslationUnitDecl *>(TU));
  }
};

} // end anonymous namespace

void ento::registerMISRAC_14_4(CheckerManager &mgr) {
    mgr.registerChecker<MISRAC_14_4_Checker>();
}

bool ento::shouldRegisterMISRAC_14_4(const CheckerManager &mgr) {
    return true;
}
