﻿// MISRA C:2012 Rule 5.6 — Typedef 重定义应具有唯一标识符
// 检测同一作用域内同名 typedef 重定义的情况

#include "clang/AST/ASTContext.h"
#include "clang/AST/RecursiveASTVisitor.h"
#include "clang/AST/Decl.h"
#include "clang/StaticAnalyzer/Core/BugReporter/BugType.h"
#include "clang/StaticAnalyzer/Core/Checker.h"
#include "clang/StaticAnalyzer/Core/PathSensitive/AnalysisManager.h"
#include "clang/StaticAnalyzer/Core/PathSensitive/CheckerContext.h"
#include "clang/StaticAnalyzer/Checkers/BuiltinCheckerRegistration.h"
#include <map>
#include <string>
#include <vector>

using namespace clang;
using namespace ento;

namespace {

class MISRAC_5_6_Checker : public Checker<check::EndOfTranslationUnit> {
  mutable std::unique_ptr<BugType> BT;

public:
  MISRAC_5_6_Checker()
      : BT(new BugType(this, "MISRA C:2012 Rule 5.6", "Typedef 重定义应具有唯一标识符")) {}

  void checkEndOfTranslationUnit(const TranslationUnitDecl *TU,
                                 AnalysisManager &Mgr,
                                 BugReporter &BR) const {
    if (!TU)
      return;

    // 使用栈跟踪作用域，每个作用域有独立的 typedef 记录
    std::vector<std::map<StringRef, SourceLocation>> ScopeStack;
    ScopeStack.emplace_back(); // 全局作用域

    class Visitor : public RecursiveASTVisitor<Visitor> {
      const MISRAC_5_6_Checker *Checker;
      std::vector<std::map<StringRef, SourceLocation>> &Scopes;
      BugReporter &BR;

    public:
      Visitor(const MISRAC_5_6_Checker *C,
              std::vector<std::map<StringRef, SourceLocation>> &S,
              BugReporter &B)
          : Checker(C), Scopes(S), BR(B) {}

      // 会创建作用域的声明类型，进入时压栈，退出时弹栈
#define DEF_SCOPE_TRAVERSE(DeclType)                                        \
      bool Traverse##DeclType(DeclType *D) {                                \
        Scopes.emplace_back();                                              \
        bool R = RecursiveASTVisitor<Visitor>::Traverse##DeclType(D);       \
        Scopes.pop_back();                                                  \
        return R;                                                           \
      }

      DEF_SCOPE_TRAVERSE(FunctionDecl)
      DEF_SCOPE_TRAVERSE(CXXMethodDecl)
      DEF_SCOPE_TRAVERSE(CXXConstructorDecl)
      DEF_SCOPE_TRAVERSE(CXXDestructorDecl)
      DEF_SCOPE_TRAVERSE(CXXConversionDecl)
      DEF_SCOPE_TRAVERSE(NamespaceDecl)
      DEF_SCOPE_TRAVERSE(BlockDecl)
      DEF_SCOPE_TRAVERSE(ObjCMethodDecl)
#undef DEF_SCOPE_TRAVERSE

      bool VisitTypedefDecl(TypedefDecl *TD) {
        if (TD->isImplicit())
          return true;

        StringRef Name = TD->getName();
        SourceLocation Loc = TD->getLocation();
        auto &Seen = Scopes.back();

        auto It = Seen.find(Name);
        if (It != Seen.end()) {
          PathDiagnosticLocation PDLoc(Loc, BR.getSourceManager());
          auto Report = std::make_unique<BasicBugReport>(
              *Checker->BT,
              "MISRA C:2012 Rule 5.6: Typedef '" + Name.str() +
                  "' 重定义，应具有唯一标识符",
              PDLoc);
          Report->addRange(TD->getSourceRange());
          Report->addNote("原始定义在此",
                          PathDiagnosticLocation(It->second,
                                                 BR.getSourceManager()));
          BR.emitReport(std::move(Report));
        } else {
          Seen[Name] = Loc;
        }
        return true;
      }
    };

    Visitor V(this, ScopeStack, BR);
    V.TraverseDecl(const_cast<TranslationUnitDecl *>(TU));
  }
};

} // end anonymous namespace

void ento::registerMISRAC_5_6(CheckerManager &mgr) {
    mgr.registerChecker<MISRAC_5_6_Checker>();
}

bool ento::shouldRegisterMISRAC_5_6(const CheckerManager &mgr) {
    return true;
}
