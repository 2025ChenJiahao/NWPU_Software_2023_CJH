﻿// MISRA C:2012 Rule 15.1 — 不应使用 goto 语句
// 检测代码中是否出现 goto 语句

#include "clang/AST/Stmt.h"
#include "clang/AST/Expr.h"
#include "clang/AST/RecursiveASTVisitor.h"
#include "clang/StaticAnalyzer/Core/BugReporter/BugType.h"
#include "clang/StaticAnalyzer/Core/Checker.h"
#include "clang/StaticAnalyzer/Core/PathSensitive/AnalysisManager.h"
#include "clang/StaticAnalyzer/Core/PathSensitive/CheckerContext.h"
#include "clang/StaticAnalyzer/Checkers/BuiltinCheckerRegistration.h"

using namespace clang;
using namespace ento;

namespace {

class MISRAC_15_1_Checker : public Checker<check::EndOfTranslationUnit> {
  mutable std::unique_ptr<BugType> BT;

public:
  MISRAC_15_1_Checker()
      : BT(new BugType(this, "MISRA C:2012 Rule 15.1", "不应使用 goto 语句")) {}

  void checkEndOfTranslationUnit(const TranslationUnitDecl *TU,
                                 AnalysisManager &Mgr,
                                 BugReporter &BR) const {
    if (!TU)
      return;

    class Visitor : public RecursiveASTVisitor<Visitor> {
      const MISRAC_15_1_Checker *Checker;
      BugReporter &BR;

    public:
      Visitor(const MISRAC_15_1_Checker *C, BugReporter &B)
          : Checker(C), BR(B) {}

      bool VisitGotoStmt(GotoStmt *GS) {
        SourceLocation GotoLoc = GS->getGotoLoc();
        PathDiagnosticLocation PDLoc(GotoLoc, BR.getSourceManager());

        LabelDecl *Label = GS->getLabel();
        std::string LabelName = Label ? Label->getName().str() : "unknown";

        auto Report = std::make_unique<BasicBugReport>(
            *Checker->BT,
            "MISRA C:2012 Rule 15.1: 不应使用 goto 语句 (跳转到标签 '" +
                LabelName + "')",
            PDLoc);
        Report->addRange(GS->getSourceRange());

        if (Label) {
          SourceLocation LabelDefLoc = Label->getLocation();
          Report->addNote("标签 '" + LabelName + "' 定义在此",
                          PathDiagnosticLocation(LabelDefLoc,
                                                 BR.getSourceManager()));
        }

        BR.emitReport(std::move(Report));
        return true;
      }
    };

    Visitor V(this, BR);
    V.TraverseDecl(const_cast<TranslationUnitDecl *>(TU));
  }
};

} // end anonymous namespace

void ento::registerMISRAC_15_1(CheckerManager &mgr) {
    mgr.registerChecker<MISRAC_15_1_Checker>();
}

bool ento::shouldRegisterMISRAC_15_1(const CheckerManager &mgr) {
    return true;
}
