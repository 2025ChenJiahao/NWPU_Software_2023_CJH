#include <stdint.h>                                                           
 #include <stdbool.h>                                                          
 static _Bool is_valid(void)                                                   
 {                                                                             
     return true;                                                              
 }                                                                             
 void test_fp_14_4(void)                                                       
 {                                                                             
     int32_t raw = 0;                                                          
     int32_t a = 3;                                                            
     int32_t b = 5;                                                            
     /* 误报点1：字面量 0/1 在 MISRA 中属于本质布尔常量，合规 */               
     if (1) {                                                                  
     }                                                                         
     while (0) {                                                               
         break;                                                                
     }                                                                         
     /* 误报点2：! 操作符产生本质布尔类型结果，合规 */                         
     if (!raw) {                                                               
     }                                                                         
     /* 误报点3：!! 操作符产生本质布尔类型结果，合规 */                        
     if (!!raw) {                                                              
     }                                                                         
     /* 误报点4：函数返回 _Bool，调用表达式为本质布尔类型，合规 */             
     if (is_valid()) {                                                         
     }                                                                         
     /* 误报点5：显式转换为 _Bool 后为本质布尔类型，合规 */                    
     if ((_Bool)raw) {                                                         
     }                                                                         
     /*                                                                        
 误报点6：三目运算符的第二/第三操作数为本质布尔表达式，整体为本质布尔类型，合  
 规 */                                                                         
     if ((a > b) ? (a != 0) : (b != 0)) {                                      
     }                                                                         
 }