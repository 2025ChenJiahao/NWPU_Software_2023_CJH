#include <stdint.h>                                                           
 #include <stdbool.h>                                                          
 void test_comply_14_4(void)                                                   
 {                                                                             
     int32_t val = 10;                                                         
     int32_t *ptr = &val;                                                      
     int32_t i;                                                                
     int32_t cnt = 3;                                                          
     bool flag = true;                                                         
     /* 合规：使用 != 0 显式比较 */                                            
     if (val != 0) {                                                           
         val = 0;                                                              
     }                                                                         
     /* 合规：指针与 NULL 显式比较 */                                          
     while (ptr != NULL) {                                                     
         ptr = NULL;                                                           
     }                                                                         
     /* 合规：for 条件中使用 > 0 比较 */                                       
     for (i = 10; i > 0; i--) {                                                
     }                                                                         
     /* 合规：_Bool 类型变量 */                                                
     if (flag) {                                                               
         flag = false;                                                         
     }                                                                         
     /* 合规：逻辑与表达式（本质是布尔类型） */                                
     if ((val > 0) && flag) {                                                  
     }                                                                         
     /* 合规：do-while 中使用 != 0 比较 */                                     
     do {                                                                      
         cnt--;                                                                
     } while (cnt != 0);                                                       
 }