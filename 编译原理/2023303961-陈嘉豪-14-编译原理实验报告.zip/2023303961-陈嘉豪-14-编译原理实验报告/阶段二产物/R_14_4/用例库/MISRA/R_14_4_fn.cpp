#include <stdint.h>                                                           
 /* 通过 typedef 隐藏 int 类型 */                                              
 typedef int32_t status_t;                                                     
 /* 宏展开隐藏非布尔表达式 */                                                  
 #define IS_READY(x) (x)                                                       
 /* 返回 int 的函数（函数名暗示布尔语义，但返回类型非 _Bool） */               
 static int32_t device_available(void)                                         
 {                                                                             
     return 1;                                                                 
 }                                                                             
 static int32_t remaining_items(void)                                          
 {                                                                             
     return 3;                                                                 
 }                                                                             
 void test_fn_14_4(void)                                                       
 {                                                                             
     int32_t a = 1;                                                            
     status_t st = 1;                                                          
     /* 漏报点1：typedef 包装的 int 用作条件，本质非布尔类型 */                
     if (st) {                                                                 
     }                                                                         
     /* 漏报点2：宏展开后变成 int 变量直接用作条件 */                          
     if (IS_READY(a)) {                                                        
     }                                                                         
     /* 漏报点3：返回 int 的函数直接用作条件（函数名暗示布尔语义） */          
     if (device_available()) {                                                 
     }                                                                         
     /* 漏报点4：枚举类型本质是 int，直接用作条件 */                           
     enum { OFF = 0, ON = 1 } state = ON;                                      
     if (state) {                                                              
     }                                                                         
     /* 漏报点5：结构体 int 成员直接用作条件 */                                
     struct {                                                                  
         int32_t ready;                                                        
     } dev = { 1 };                                                            
     if (dev.ready) {                                                          
     }                                                                         
     /* 漏报点6：数组 int 元素直接用作条件 */                                  
     int32_t flags[3] = {0, 1, 0};                                             
     if (flags[1]) {                                                           
     }                                                                         
     /* 漏报点7：int 返回值直接用于 for 条件 */                                
     for (; remaining_items(); ) {                                             
         break;                                                                
     }                                                                         
 }