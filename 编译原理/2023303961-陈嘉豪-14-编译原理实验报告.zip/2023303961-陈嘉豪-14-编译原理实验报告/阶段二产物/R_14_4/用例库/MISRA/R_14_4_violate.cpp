#include <stdint.h>                                                           
 void test_violate_14_4(void)                                                  
 {                                                                             
     int32_t val = 10;                                                         
     int32_t *ptr = &val;                                                      
     int32_t i;                                                                
     int32_t cnt = 3;                                                          
     /* 违规：整数变量用作 if 控制表达式 */                                    
     if (val) {                                                                
         val = 0;                                                              
     }                                                                         
     /* 违规：指针用作 while 控制表达式 */                                     
     while (ptr) {                                                             
         ptr = 0;                                                              
     }                                                                         
     /* 违规：整数变量用作 for 控制表达式 */                                   
     for (i = 10; i; i--) {                                                    
     }                                                                         
     /* 违规：整数变量用作 do-while 控制表达式 */                              
     do {                                                                      
         cnt--;                                                                
     } while (cnt);                                                            
 }