typedef int myInt32;                                                          
 typedef long myInt64;                                                         
 int main(void) {                                                              
     myInt32 a = 0;                                                            
     myInt64 b = 0;                                                            
     (void)a;                                                                  
     (void)b;                                                                  
     return 0;                                                                 
 }