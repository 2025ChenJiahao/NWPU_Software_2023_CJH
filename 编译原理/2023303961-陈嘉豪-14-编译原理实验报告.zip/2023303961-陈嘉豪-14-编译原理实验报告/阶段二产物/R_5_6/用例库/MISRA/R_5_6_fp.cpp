void func_a(void) {                                                           
     typedef int localType;                                                    
     localType a = 0;                                                          
     (void)a;                                                                  
 }                                                                             
 void func_b(void) {                                                           
     typedef long localType;                                                   
     localType b = 0;                                                          
     (void)b;                                                                  
 }                                                                             
 int main(void) {                                                              
     func_a();                                                                 
     func_b();                                                                 
     return 0;                                                                 
 }