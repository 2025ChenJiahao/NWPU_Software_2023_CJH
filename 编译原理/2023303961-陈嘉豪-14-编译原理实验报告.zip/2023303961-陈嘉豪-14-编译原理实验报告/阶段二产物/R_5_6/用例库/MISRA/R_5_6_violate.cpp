typedef int myInt;                                                            
 typedef int myInt;                                                            
 int main(void) {                                                              
     myInt x = 0;                                                              
     (void)x;                                                                  
     return 0;                                                                 
 }