#define TYPEDEF_SAME(t, n) typedef t n                                        
 TYPEDEF_SAME(int, myType);
 int main(void) {                                                              
     myType x = 0;                                                             
     (void)x;                                                                  
     return 0;                                                                 
 }