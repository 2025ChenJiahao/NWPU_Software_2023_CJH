#include <stddef.h>

int test_violate(int flag) {
    int result = -1;
    int *buf = NULL;

    if (buf == NULL) {
        return result;
    }

    *buf = 42;
    result = 0;
    return result;
}