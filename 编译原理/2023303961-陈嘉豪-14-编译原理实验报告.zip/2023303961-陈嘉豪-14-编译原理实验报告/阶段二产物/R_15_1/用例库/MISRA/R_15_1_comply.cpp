#include <stddef.h>                                                           
 int test_comply(int flag) {                                                   
     int result = -1;                                                          
     int *buf = NULL;                                                          
     do {                                                                      
         if (buf == NULL) {                                                    
             break;                                                            
         }                                                                     
         *buf = 42;                                                            
         result = 0;                                                           
     } while (0);                                                              
     return result;                                                            
 }