#include <stddef.h>                                                           
 int test_fp(int flag) {                                                       
     int result = -1;                                                          
     int *buf = NULL;                                                          
     if (buf == NULL) {                                                        
 #if 0                                                                         
         goto cleanup;                                                         
 #endif                                                                        
         return result;                                                        
     }                                                                         
     *buf = 42;                                                                
     result = 0;                                                               
 #if 0                                                                         
 cleanup:                                                                      
     return result;                                                            
 #endif                                                                        
     return result;                                                            
 }