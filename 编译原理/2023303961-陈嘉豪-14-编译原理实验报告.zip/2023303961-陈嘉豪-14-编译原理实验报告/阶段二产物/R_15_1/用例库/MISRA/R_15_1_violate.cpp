#include <stddef.h>                                                           
 int test_violate(int flag) {                                                  
     int result = -1;                                                          
     int *buf = NULL;                                                          
     if (buf == NULL) {                                                        
         goto cleanup;                                                         
     }                                                                         
     *buf = 42;                                                                
     result = 0;                                                               
 cleanup:                                                                      
     return result;                                                            
 }