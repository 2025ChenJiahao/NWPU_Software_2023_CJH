#include <stddef.h>                                                           
 #define BAIL_OUT do { goto cleanup; } while (0)                               
 int test_fn(int flag) {                                                       
     int result = -1;                                                          
     int *buf = NULL;                                                          
     if (buf == NULL) {                                                        
         BAIL_OUT;                                                             
     }                                                                         
     *buf = 42;                                                                
     result = 0;                                                               
 cleanup:                                                                      
     return result;                                                            
 }