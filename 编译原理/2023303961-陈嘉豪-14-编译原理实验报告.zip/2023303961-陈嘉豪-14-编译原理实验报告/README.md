# 编译原理实验 — MISRA C:2012 静态检测项开发

基于 LLVM/Clang 技术栈，为 MISRA C:2012 规则集中的三条规则开发静态检测项（Checker），并使用 nanobot 自动化工具完成测试与缺陷修复。

## 规则列表

| 规则编号 | 所属类别 | 规则要求 |
|----------|----------|----------|
| Rule 5.6 | 标识符 | Typedef 重定义应具有唯一标识符 |
| Rule 14.4 | 控制表达式 | if/while/for 的控制表达式必须是布尔类型 |
| Rule 15.1 | 控制流 | 不应使用 goto 语句 |

## 项目结构

```
2023303961/
├── 阶段一源文件/                    # Clang Checker 源码
│   ├── MISRAC_5_6_Checker.cpp       # Rule 5.6 检测项
│   ├── MISRAC_14_4_Checker.cpp      # Rule 14.4 检测项
│   ├── MISRAC_15_1_Checker.cpp      # Rule 15.1 检测项
│   └── Checkers注册说明/            # 注册配置文件
│       ├── Checkers.td              # 完整的 Checkers.td
│       ├── Checkers.td添加内容.txt   # 新增内容说明
│       ├── CMakeLists.txt           # 完整的 CMakeLists.txt
│       └── CMakeLists.txt添加内容.txt
├── 阶段二产物/                      # 测试用例与修复产物
│   ├── R_5_6/                       # Rule 5.6 相关
│   │   ├── 用例库/MISRA/            # 原始测试用例
│   │   └── 用例库副本/MISRA/        # 缺陷修复后的用例
│   ├── R_14_4/                      # Rule 14.4 相关
│   ├── R_15_1/                      # Rule 15.1 相关
│   └── 关联关系.txt                  # 规则与用例映射
└── README.md
```

## 环境依赖

- **操作系统：** Windows 11
- **编译器工具链：** Visual Studio 2022 BuildTools + MSVC
- **构建系统：** CMake（通过 `winget install Kitware.CMake` 安装）
- **LLVM/Clang：** 17.0.5（浅克隆 `git clone --branch llvmorg-17.0.5 --depth 1`）
- **Python：** 3.12（运行 nanobot 自动化脚本）
- **nanobot：** 自动化代码检测代理工具

## 快速开始

### 阶段一：编译自定义 Clang

```bash
# 1. 克隆 LLVM 源码
cd D:/
git clone --branch llvmorg-17.0.5 --depth 1 https://github.com/llvm/llvm-project.git

# 2. 将 Checker 源码放入检测项目录
cp 阶段一源文件/MISRAC_*.cpp D:/llvm-project/clang/lib/StaticAnalyzer/Checkers/

# 3. 修改 Checkers.td 和 CMakeLists.txt（见 阶段一源文件/Checkers注册说明/）

# 4. CMake 配置
cd D:/llvm-project/build
cmake -DLLVM_ENABLE_PROJECTS=clang -G "Visual Studio 17 2022" -A x64 -Thost=x64 ../llvm

# 5. 用 VS2022 打开 LLVM.sln，Release x64 编译 clang 目标
```

### 阶段二：运行自动化检测

```bash
# 对每条规则运行检测
python nanobot_auto_checker.py \
  --clang-path "D:/llvm-project/build/Release/bin/clang.exe" \
  --rule-set MISRA --rule-id R_5_6

python nanobot_auto_checker.py \
  --clang-path "D:/llvm-project/build/Release/bin/clang.exe" \
  --rule-set MISRA --rule-id R_14_4

python nanobot_auto_checker.py \
  --clang-path "D:/llvm-project/build/Release/bin/clang.exe" \
  --rule-set MISRA --rule-id R_15_1
```

## 测试用例设计

每条规则包含四类测试用例：

| 类型 | 文件后缀 | 预期结果 | 说明 |
|------|----------|----------|------|
| 违规用例 | `_violate.cpp` | 报出缺陷 | 明显触发规则 |
| 合规用例 | `_comply.cpp` | 不报出 | 完全遵守规则 |
| 漏报边界 | `_fn.cpp` | 报出缺陷 | 隐蔽写法，易漏报 |
| 误报边界 | `_fp.cpp` | 不报出 | 语义安全，易误报 |
